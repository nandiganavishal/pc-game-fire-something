import pygame
import sys
import asyncio
import random

# --- Configuration ---
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
VERTICAL_OFFSET = 50 
SOURCE_SPEED = 5
SHOOT_SPEED = 1 
SHOOT_COOLDOWN = 300 # milliseconds between shots
REACHED_DURATION = 2000 # Time the reached image stays visible

# Image Scaling Sizes
REACHED_SIZE = (200, 200) # Defined as a tuple (width, height)
SOURCE_SIZE = (SCREEN_WIDTH//3, SCREEN_HEIGHT//3) 
SHOOT_SIZE = (300, 300) 

# Colors
WHITE = (255, 255, 255)

# Total number of game stages/image pairs
NUM_STAGES = 4

class Projectile(pygame.sprite.Sprite):
    """Represents a moving shoot projectile."""
    def __init__(self, x, y, direction, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.direction = direction 

    def update(self):
        """Updates the projectile's position."""
        self.rect.y += self.direction * SHOOT_SPEED
        if self.rect.bottom < 0:
            self.kill()

# The main game function must be asynchronous for pygbag compatibility
async def main():
    pygame.init()

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Level 1 Game Environment")

    # --- File Names Lists ---
    source_files = ['source1.jpg', 'source2.jpg', 'source3.jpg', 'source4.jpg']
    reached_files = ['reached1.jpg', 'reached2.jpg', 'reached3.jpg', 'reached4.jpg']
    shoot_file = 'shoot.jpg'
    # ------------------
    
    shoot_image_ref = None 
    loaded_source_images = []
    loaded_reached_images = [] 

    # --- Load Images ---
    try:
        shoot_image_ref = pygame.image.load(shoot_file)
        shoot_image_ref = pygame.transform.scale(shoot_image_ref, SHOOT_SIZE) 
        
        for file in source_files:
            img = pygame.image.load(file)
            img = pygame.transform.scale(img, SOURCE_SIZE)
            loaded_source_images.append(img)

        for file in reached_files:
            img = pygame.image.load(file)
            img = pygame.transform.scale(img, REACHED_SIZE)
            loaded_reached_images.append(img)
            
        background_image = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        background_image.fill(WHITE)

    except pygame.error as e:
        print(f"Error loading a core image file: {e}")
        print("Please ensure all required sourceN, reachedN, and shoot jpgs are in your directory.")
        sys.exit()
    # -------------------

    # Start the game at stage 0 (index 0 for lists)
    current_game_stage_index = 0
    current_source_image = loaded_source_images[current_game_stage_index]
    
    source_width = current_source_image.get_width()
    source_height = current_source_image.get_height()
    source_x = (SCREEN_WIDTH // 2) - (source_width // 2)
    source_y = SCREEN_HEIGHT - source_height - VERTICAL_OFFSET
    
    # Calculate fixed reached image display coordinates
    # --- FIX FOR TypeError: use the width component (index 0) of the REACHED_SIZE tuple ---
    # The traceback image showed this exact line causing the error:
    reached_x = (SCREEN_WIDTH // 2) - (REACHED_SIZE[0] // 2) 
    reached_y = 100 
    # -------------------------------------------------------------------------------------

    all_projectiles = pygame.sprite.Group()
    
    last_shot_time = pygame.time.get_ticks()
    
    is_reached_displayed = False
    display_time = 0
    current_reached_image_to_show = None

    GAME_MODE_SEQUENTIAL = 0
    GAME_MODE_RANDOM = 1
    game_mode = GAME_MODE_SEQUENTIAL
    
    loop_count = 0

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN:
                current_time = pygame.time.get_ticks()
                if event.key in [pygame.K_UP, pygame.K_SPACE]:
                    if current_time - last_shot_time > SHOOT_COOLDOWN:
                        new_shoot = Projectile(
                            x=source_x + (source_width // 2), 
                            y=source_y, 
                            direction=-1,
                            image=shoot_image_ref 
                        )
                        all_projectiles.add(new_shoot)
                        last_shot_time = current_time
                        
                        is_reached_displayed = True
                        display_time = current_time
                        current_reached_image_to_show = loaded_reached_images[current_game_stage_index]


        # --- Game Logic Updates ---
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            source_x -= SOURCE_SPEED
        if keys[pygame.K_RIGHT]:
            source_x += SOURCE_SPEED
        
        source_x = max(0, min(source_x, SCREEN_WIDTH - source_width))

        all_projectiles.update()
        current_time = pygame.time.get_ticks()

        if is_reached_displayed and (current_time - display_time) > REACHED_DURATION: 
            is_reached_displayed = False
            current_reached_image_to_show = None
            
            if current_game_stage_index == NUM_STAGES - 1:
                loop_count += 1
                if loop_count >= 1:
                    game_mode = GAME_MODE_RANDOM
                    print("Switched to Random Mode!")

            if game_mode == GAME_MODE_SEQUENTIAL:
                current_game_stage_index = (current_game_stage_index + 1) % NUM_STAGES
            
            elif game_mode == GAME_MODE_RANDOM:
                current_game_stage_index = random.randint(0, NUM_STAGES - 1)

            current_source_image = loaded_source_images[current_game_stage_index]
            
            source_width = current_source_image.get_width()
            source_height = current_source_image.get_height()
            source_x = (SCREEN_WIDTH // 2) - (source_width // 2)


        # --- Drawing ---
        screen.blit(background_image, (0, 0)) 
        
        if is_reached_displayed and current_reached_image_to_show:
            screen.blit(current_reached_image_to_show, (reached_x, reached_y))
            
        screen.blit(current_source_image, (source_x, source_y)) 
        
        all_projectiles.draw(screen)
        
        pygame.display.flip()
        await asyncio.sleep(0) 

    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    asyncio.run(main())
