import pygame
import sys
import asyncio
import random # Ensure random is imported

# --- Configuration ---
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
VERTICAL_OFFSET = 50 
SOURCE_SPEED = 5
SHOOT_SPEED = 1 
SHOOT_COOLDOWN = 300 # milliseconds between shots
BOXBOARD_CHANGE_RATE = 3000 
BOXBOARD_Y_POSITION = 100 # Fixed Y position for the single boxboard
# Time the 'won' image stays visible before spawning a new normal target
WON_STATE_DURATION = 2000 

# Image Scaling Sizes
BASE_SIZE = (200, 200) # Use one base size for both boxboard and wonboard
SOURCE_SIZE = (SCREEN_WIDTH//6, SCREEN_HEIGHT//6) 
SHOOT_SIZE = (300, 300) 

# Colors
WHITE = (255, 255, 255)

# Define states for the boxboard
STATE_NORMAL = 0
STATE_WON = 1

class Projectile(pygame.sprite.Sprite):
    """Represents a moving shoot projectile."""
    def __init__(self, x, y, direction, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.direction = direction 

    def update(self):
        """Updates the projectile's position."""
        self.rect.y += self.direction * SHOOT_SPEED
        if self.rect.bottom < 0:
            self.kill()

class BoxboardTarget(pygame.sprite.Sprite):
    """
    Represents a stationary target that cycles through normal boxboard images,
    and changes to a 'won' state with a random won image when hit.
    """
    def __init__(self, x, y, normal_images_list, won_images_list):
        super().__init__()
        self.normal_images = normal_images_list 
        self.won_images = won_images_list
        self.image_index = 0
        self.state = STATE_NORMAL 
        self.last_update_time = pygame.time.get_ticks()
        self.hit_time = 0

        # Start with the initial normal image
        self.image = self.normal_images[self.image_index]
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y

    def update(self, current_time):
        """Updates the boxboard's image for animation and state transitions."""
        if self.state == STATE_NORMAL:
            # Cycle through the normal boxboard images for animation
            if current_time - self.last_update_time > BOXBOARD_CHANGE_RATE:
                self.image_index = (self.image_index + 1) % len(self.normal_images)
                self._update_image_surface(self.normal_images)
                self.last_update_time = current_time
        
        elif self.state == STATE_WON:
            # Check if enough time has passed to despawn and spawn a new target
            if current_time - self.hit_time > WON_STATE_DURATION:
                self.kill() # Signal the main loop to spawn a new target

    def _update_image_surface(self, images_list):
        """Helper to swap the current image surface while maintaining position."""
        center = self.rect.center
        self.image = images_list[self.image_index] 
        self.rect = self.image.get_rect()
        self.rect.center = center

    def get_hit(self):
        """Handles the transition to the 'won' state."""
        if self.state == STATE_NORMAL:
            self.state = STATE_WON
            # FIXED: Select a random index for the won image
            self.image_index = random.randint(0, len(self.won_images) - 1)
            self._update_image_surface(self.won_images)
            self.hit_time = pygame.time.get_ticks()


# The main game function must be asynchronous for pygbag compatibility
async def main():
    pygame.init()

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Level 1 Game Environment (Random Wonboard image added)")

    source_file = 'source.jpg'
    shoot_file = 'shoot.jpg'
    normal_boxboard_files = ['boxboard1.jpg', 'boxboard2.jpg', 'boxboard3.jpg', 'boxboard4.jpg']
    won_boxboard_files = ['wonboard1.jpg', 'wonboard2.jpg', 'wonboard3.jpg', 'wonboard4.jpg'] # Added won images
    
    loaded_normal_images = []
    loaded_won_images = []
    shoot_image_ref = None 

    # --- Load Images ---
    try:
        source_image = pygame.image.load(source_file)
        source_image = pygame.transform.scale(source_image, SOURCE_SIZE)
        
        shoot_image_ref = pygame.image.load(shoot_file)
        shoot_image_ref = pygame.transform.scale(shoot_image_ref, SHOOT_SIZE) 
        
        for file in normal_boxboard_files:
            img = pygame.image.load(file)
            img = pygame.transform.scale(img, BASE_SIZE) 
            loaded_normal_images.append(img)

        for file in won_boxboard_files:
            img = pygame.image.load(file)
            img = pygame.transform.scale(img, BASE_SIZE)
            loaded_won_images.append(img)
            
        background_image = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        background_image.fill(WHITE)

    except pygame.error as e:
        print(f"Error loading a core image file: {e}")
        print("Please ensure all source, shoot, boxboard1-4, and wonboard1-4 jpgs are in your directory.")
        sys.exit()
    # -------------------

    # Calculate initial source position
    source_width = source_image.get_width()
    source_height = source_image.get_height()
    source_x = (SCREEN_WIDTH // 2) - (source_width // 2)
    source_y = SCREEN_HEIGHT - source_height - VERTICAL_OFFSET

    all_projectiles = pygame.sprite.Group()
    all_targets = pygame.sprite.GroupSingle() 
    
    next_boxboard_index_to_spawn = 0

    def spawn_new_boxboard():
        nonlocal next_boxboard_index_to_spawn
        
        spawn_x = random.randint(0, SCREEN_WIDTH - BASE_SIZE[0]) 
        new_boxboard = BoxboardTarget(
            x=spawn_x, 
            y=BOXBOARD_Y_POSITION, 
            normal_images_list=loaded_normal_images,
            won_images_list=loaded_won_images
        )
        new_boxboard.image_index = next_boxboard_index_to_spawn
        new_boxboard._update_image_surface(loaded_normal_images) 

        all_targets.add(new_boxboard)

        next_boxboard_index_to_spawn = (next_boxboard_index_to_spawn + 1) % len(loaded_normal_images)

    last_shot_time = pygame.time.get_ticks()

    spawn_new_boxboard()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN:
                current_time = pygame.time.get_ticks()
                if event.key in [pygame.K_UP, pygame.K_SPACE]:
                    if current_time - last_shot_time > SHOOT_COOLDOWN and all_targets.sprite and all_targets.sprite.state == STATE_NORMAL:
                        new_shoot = Projectile(
                            x=source_x + (source_width // 2), 
                            y=source_y, 
                            direction=-1,
                            image=shoot_image_ref 
                        )
                        all_projectiles.add(new_shoot)
                        last_shot_time = current_time

        # --- Game Logic Updates ---
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            source_x -= SOURCE_SPEED
        if keys[pygame.K_RIGHT]:
            source_x += SOURCE_SPEED
        
        source_x = max(0, min(source_x, SCREEN_WIDTH - source_width))

        all_projectiles.update()
        current_time = pygame.time.get_ticks()
        
        all_targets.update(current_time) 
            
        current_target = all_targets.sprite
        if current_target and current_target.state == STATE_NORMAL:
            hits = pygame.sprite.spritecollide(current_target, all_projectiles, True) 
            if hits:
                print("Boxboard hit! Switching to won state with random image.")
                current_target.get_hit()
        
        if not all_targets.sprite:
            print("Spawning new target at a new location.")
            spawn_new_boxboard()

        # --- Drawing ---
        screen.blit(background_image, (0, 0)) 
        screen.blit(source_image, (source_x, source_y)) 
        
        all_projectiles.draw(screen)
        all_targets.draw(screen) 

        # Update the display
        pygame.display.update()
        
        await asyncio.sleep(0) 

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
