import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# --- Configuration ---
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
FPS = 30
PLAYER_SPEED = 5
GRASS_Y_START = 200 

# Set up the display
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Sequential and Random Background Game")

# Clock for controlling frame rate
clock = pygame.time.Clock()

# --- Load Image Assets ---
try:
    # Load all background images and scale them
    bg1_surface = pygame.image.load('prog1.jpg').convert_alpha()
    background_image_1 = pygame.transform.scale(bg1_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))

    bg2_surface = pygame.image.load('prog2.jpg').convert_alpha()
    background_image_2 = pygame.transform.scale(bg2_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))
    
    bg3_surface = pygame.image.load('prog3.jpg').convert_alpha()
    background_image_3 = pygame.transform.scale(bg3_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))

    bg4_surface = pygame.image.load('prog4.jpg').convert_alpha()
    background_image_4 = pygame.transform.scale(bg4_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))
    
    # Store all backgrounds in a list for random access later
    all_backgrounds = [
        background_image_1, 
        background_image_2, 
        background_image_3, 
        background_image_4
    ]
    
    # Load the player image from guy.jpg and scale it
    player_surface = pygame.image.load('guy.jpg').convert_alpha()
    player_surface = pygame.transform.scale(player_surface, (40, 40))
    player_rect = player_surface.get_rect()

    # Load the coin image from coin.jpg and scale it
    coin_surface = pygame.image.load('coin.jpg').convert_alpha()
    coin_surface = pygame.transform.scale(coin_surface, (50, 50)) 
    coin_rect = coin_surface.get_rect()

except pygame.error as e:
    print(f"Error loading images: {e}")
    print("Please ensure all image files are in the same folder.")
    sys.exit()

# --- Game Objects Setup ---

# Player setup 
player_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)

# Function to place the coin randomly
def place_coin():
    coin_rect.x = random.randint(0, SCREEN_WIDTH - coin_rect.width)
    coin_rect.y = random.randint(GRASS_Y_START, SCREEN_HEIGHT - coin_rect.height)

place_coin() 

# Score
score = 0
font = pygame.font.Font(None, 36)

# Variable to track the current background image
current_background = background_image_1 # Start with prog1.jpg

# --- Game Loop ---
running = True
while running:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # --- Player Movement ---
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_rect.left > 0:
        player_rect.x -= PLAYER_SPEED
    if keys[pygame.K_RIGHT] and player_rect.right < SCREEN_WIDTH:
        player_rect.x += PLAYER_SPEED
    if keys[pygame.K_UP] and player_rect.top > GRASS_Y_START:
        player_rect.y -= PLAYER_SPEED
    if keys[pygame.K_DOWN] and player_rect.bottom < SCREEN_HEIGHT:
        player_rect.y += PLAYER_SPEED

    # --- Collision Detection & Background Switch Logic ---
    if player_rect.colliderect(coin_rect):
        score += 1
        place_coin()
        
        # Check the current score to decide which background to use next
        if score == 1:
            current_background = background_image_2 
        elif score == 2:
            current_background = background_image_3
        elif score == 3:
            current_background = background_image_4
        else:
            # For 4th coin collected (score 4) and onwards, pick a random background
            current_background = random.choice(all_backgrounds)

    # --- Drawing ---
    # Draw the CURRENT background image
    screen.blit(current_background, (0, 0)) 

    # Draw the player (guy.jpg)
    screen.blit(player_surface, player_rect)

    # Draw the coin (coin.jpg)
    screen.blit(coin_surface, coin_rect)

    # Draw the score overlay
    score_text = font.render(f"Score: {score}", True, (0, 0, 0))
    screen.blit(score_text, (10, 10))

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()
