import pygame
import subprocess
import sys
import os

# Get the base directory where main.py is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Define the relative paths to your level files
LEVEL_DATA = {
    "Level 1": {"folder": "level1", "script": "main_level1.py"},
    "Level 2": {"folder": "level2", "script": "main_level2.py"},
    "Level 3": {"folder": "level3", "script": "main_level3.py"},
}
IMAGE_PATH = os.path.join(BASE_DIR, 'levels.jpg')

# Define the clickable areas (Rectangles) using your exact measurements (x, y, width, height)
BUTTON_RECTS = {
    "Level 1": pygame.Rect(0, 170, 1000, 130), 
    "Level 2": pygame.Rect(0, 320, 1000, 130), 
    "Level 3": pygame.Rect(0, 470, 1000, 130), 
}

def run_level(level_name, level_info):
    """
    Runs a level script using a subprocess and sets its working directory.
    This fixes the FileNotFoundError in the level scripts.
    """
    script_folder = level_info["folder"]
    script_name = level_info["script"]
    
    # Construct the absolute path to the folder containing the level script and images
    working_directory = os.path.join(BASE_DIR, script_folder)
    # The command to execute is just the script name, as 'cwd' handles the location
    command = [sys.executable, script_name]

    print(f"--- Attempting to run: {level_name} ---")
    
    try:
        # CRITICAL FIX: Use the 'cwd' argument to set the working directory for the subprocess
        subprocess.call(command, cwd=working_directory) 
    except FileNotFoundError as e:
        print(f"Error executing script: {e}")
        print(f"Ensure Python is in your system PATH and that all images are in {working_directory}")
    
    print(f"Finished {script_name}. Returning to menu.")

def main():
    pygame.init()

    try:
        menu_image = pygame.image.load(IMAGE_PATH)
    except pygame.error as e:
        print(f"Error loading image: {e}")
        return

    # Set up the display using the image dimensions
    screen = pygame.display.set_mode(menu_image.get_size())
    pygame.display.set_caption("Level Selection Menu")

    running = True
    while running:
        # Draw the image onto the screen
        screen.blit(menu_image, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Check if the mouse click position collides with any button area
                mouse_pos = event.pos
                for level_name, rect in BUTTON_RECTS.items():
                    if rect.collidepoint(mouse_pos):
                        print(f"Clicked within the region for: {level_name}") 
                        run_level(level_name, LEVEL_DATA[level_name])
                        # After the level returns, refresh the display caption/focus
                        pygame.display.set_caption("Level Selection Menu")

        # Update the display to show the image
        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
