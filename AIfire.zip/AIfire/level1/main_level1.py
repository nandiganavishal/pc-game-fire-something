import pygame
import sys
import asyncio
import random

# --- Configuration ---
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
VERTICAL_OFFSET = 50 
GUN_SPEED = 5
FIRE_SPEED = 10
FIRE_COOLDOWN = 300 # milliseconds between shots
NORMAL_DRAGON_CHANGE_RATE = 1000 # milliseconds to change the normal dragon image 
DRAGON_Y_POSITION = 100 # Fixed Y position for the single dragon
DEATH_IMAGE_DISPLAY_TIME = 500 # How long a single death image stays visible (0.5 seconds)

# Image Scaling Sizes
BASE_DRAGON_SIZE = (200, 200) 
LARGE_DRAGON_SIZE = (280, 280) 
GUN_SIZE = (SCREEN_WIDTH//6, SCREEN_HEIGHT//6) 
FIRE_SIZE = (60, 60) # Decreased the fire image size slightly from (80, 80)
# ---------------------

# Colors
WHITE = (255, 255, 255)

# Define states for the dragon
STATE_NORMAL = 0
STATE_DEAD = 1

class Projectile(pygame.sprite.Sprite):
    """Represents a moving fire projectile."""
    def __init__(self, x, y, direction, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.direction = direction 

    def update(self):
        self.rect.y += self.direction * FIRE_SPEED
        if self.rect.bottom < 0:
            self.kill()

class Dragon(pygame.sprite.Sprite):
    """
    Represents a stationary enemy dragon with different image sequences for states.
    """
    def __init__(self, x, y, images_dict):
        super().__init__()
        self.images_dict = images_dict 
        self.state = STATE_NORMAL
        self.current_image_list = self.images_dict['normal']
        self.image_index = 0
        self.image = self.current_image_list[self.image_index]
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.last_update_time = pygame.time.get_ticks()

    def update(self, current_time):
        if self.state == STATE_NORMAL:
            if current_time - self.last_update_time > NORMAL_DRAGON_CHANGE_RATE:
                self.image_index = (self.image_index + 1) % len(self.current_image_list)
                self._update_image_surface()
                self.last_update_time = current_time
        
    def _update_image_surface(self):
        center = self.rect.center
        self.image = self.current_image_list[self.image_index]
        self.rect = self.image.get_rect()
        self.rect.center = center

    def set_state_dead(self, specific_dead_image_index):
        """Transitions the dragon to the dead state using a specific image."""
        self.state = STATE_DEAD
        self.current_image_list = self.images_dict['dead']
        self.image_index = specific_dead_image_index % len(self.current_image_list)
        self._update_image_surface()
        self.lifetime_end_time = pygame.time.get_ticks() + DEATH_IMAGE_DISPLAY_TIME


# The main game function must be asynchronous for pygbag
async def main():
    pygame.init()

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Gun, Dragon, and Fire (Pygbag Version)")

    gun_file = 'gun.jpg'
    fire_file = 'fire.jpg'
    
    normal_dragon_files = ['dragon1.jpg', 'dragon2.jpg', 'dragon3.jpg', 'dragon4.jpg']
    dead_dragon_files = ['deaddragon1.jpg', 'deaddragon2.jpg', 'deaddragon3.jpg', 'deaddragon4.jpg'] 
    
    loaded_images = {'normal': [], 'dead': []}
    
    # --- Load Images ---
    try:
        background_image = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        background_image.fill(WHITE)

        gun_image = pygame.image.load(gun_file)
        gun_image = pygame.transform.scale(gun_image, GUN_SIZE)
        
        fire_image = pygame.image.load(fire_file)
        # Use the adjusted FIRE_SIZE variable for scaling
        fire_image = pygame.transform.scale(fire_image, FIRE_SIZE) 
        
        for file in normal_dragon_files:
            img = pygame.image.load(file)
            img = pygame.transform.scale(img, BASE_DRAGON_SIZE) 
            loaded_images['normal'].append(img)
            
        for file in dead_dragon_files:
            img = pygame.image.load(file)
            if 'deaddragon2' in file or 'deaddragon3' in file:
                img = pygame.transform.scale(img, LARGE_DRAGON_SIZE) 
            else:
                img = pygame.transform.scale(img, BASE_DRAGON_SIZE)

            loaded_images['dead'].append(img)

    except pygame.error as e:
        print(f"Error loading an image file: {e}")
        print("Please ensure you have all 9 image files in your directory.")
        sys.exit()
    # -------------------

    gun_width = gun_image.get_width()
    gun_height = gun_image.get_height()
    gun_x = (SCREEN_WIDTH // 2) - (gun_width // 2)
    gun_y = SCREEN_HEIGHT - gun_height - VERTICAL_OFFSET

    all_projectiles = pygame.sprite.Group()
    
    current_dragon = None 
    next_dead_image_index = 0

    def spawn_new_normal_dragon():
        nonlocal current_dragon
        # Use the width of the scaled base image for accurate positioning calculation
        # Note: BASE_DRAGON_SIZE is a tuple (width, height), so use index 0 for width
        spawn_x = random.randint(0, SCREEN_WIDTH - BASE_DRAGON_SIZE[0])
        current_dragon = Dragon(x=spawn_x, y=DRAGON_Y_POSITION, images_dict=loaded_images)

    last_shot_time = pygame.time.get_ticks()

    spawn_new_normal_dragon()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN:
                current_time = pygame.time.get_ticks()
                if event.key in [pygame.K_UP, pygame.K_DOWN]:
                    if current_time - last_shot_time > FIRE_COOLDOWN:
                        new_fire = Projectile(
                            x=gun_x + (gun_width // 2), 
                            y=gun_y, 
                            direction=-1, 
                            image=fire_image
                        )
                        all_projectiles.add(new_fire)
                        last_shot_time = current_time

        # --- Game Logic Updates ---
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            gun_x -= GUN_SPEED
        if keys[pygame.K_RIGHT]:
            gun_x += GUN_SPEED
        
        gun_x = max(0, min(gun_x, SCREEN_WIDTH - gun_width))

        all_projectiles.update()
        current_time = pygame.time.get_ticks()
        
        if current_dragon:
            current_dragon.update(current_time) 

            if current_dragon.state == STATE_DEAD:
                if current_time >= current_dragon.lifetime_end_time:
                    current_dragon = None 
            
            elif current_dragon.state == STATE_NORMAL:
                hits = pygame.sprite.spritecollide(current_dragon, all_projectiles, True)
                if hits:
                    print(f"Dragon hit! Transitioning to dead image index: {next_dead_image_index}")
                    current_dragon.set_state_dead(next_dead_image_index)
                    next_dead_image_index = (next_dead_image_index + 1) % len(loaded_images['dead'])
        
        if current_dragon is None:
            spawn_new_normal_dragon()

        # --- Drawing ---
        screen.fill(WHITE)
        screen.blit(background_image, (0, 0)) 
        screen.blit(gun_image, (gun_x, gun_y)) 
        
        all_projectiles.draw(screen)

        if current_dragon:
            screen.blit(current_dragon.image, current_dragon.rect)

        # Update the display
        pygame.display.update()
        
        await asyncio.sleep(0) 

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
